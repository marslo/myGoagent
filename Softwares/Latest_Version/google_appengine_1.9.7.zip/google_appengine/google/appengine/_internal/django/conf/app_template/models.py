from google.appengine._internal.django.db import models

# Create your models here.
